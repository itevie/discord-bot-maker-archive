const botManager = require(__dirname + "/../../botManager.js");

module.exports.details = {
    name: "Moderation"
}

module.exports.actions = {
    
}