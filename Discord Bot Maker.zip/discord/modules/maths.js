const botManager = require(__dirname + "/../../botManager.js");

module.exports.details = {
    name: "Maths"
}

module.exports.actions = {
    "plus": {
        allowedEvents: ["*"],
        name: "Plus (+)",
        needs: ["content", "content2"],
        inputs: {
            content: "number 1",
            content2: "number 2"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                resolve(parseFloat(data.action.content) + parseFloat(data.action.content2));
            });
        }
    },

    "subtract": {
        allowedEvents: ["*"],
        name: "Subtract (-)",
        needs: ["content", "content2"],
        inputs: {
            content: "number 1",
            content2: "number 2"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                resolve(parseFloat(data.action.content) - parseFloat(data.action.content2));
            });
        }
    },

    "multiply": {
        allowedEvents: ["*"],
        name: "Multiply (*)",
        needs: ["content", "content2"],
        inputs: {
            content: "number 1",
            content2: "number 2"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                resolve(parseFloat(data.action.content) * parseFloat(data.action.content2));
            });
        }
    },

    "divide": {
        allowedEvents: ["*"],
        name: "Divide (/)",
        needs: ["content", "content2"],
        inputs: {
            content: "number 1",
            content2: "number 2"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                resolve(parseFloat(data.action.content) / parseFloat(data.action.content2));
            });
        }
    },

    "power": {
        allowedEvents: ["*"],
        name: "Power (^)",
        needs: ["content", "content2"],
        inputs: {
            content: "number 1",
            content2: "number 2"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                resolve(Math.pow(parseFloat(data.action.content), parseFloat(data.action.content2)));
            });
        }
    },

    "floor": {
        allowedEvents: ["*"],
        name: "Floor",
        needs: ["content"],
        inputs: {
            content: "number",
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                resolve(Math.floor(parseFloat(data.action.data)));
            });
        }
    },
}