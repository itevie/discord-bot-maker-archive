const botManager = require(__dirname + "/../../botManager.js");
const parse = require(__dirname + "/../utils/parser.js").parse;

module.exports.details = {
    name: "Database"
}

module.exports.actions = {
    "fetch-database-item": {
        allowedEvents: ["*"],
        name: "Fetch Database Item",
        needs: ["id"],
        inputs: {
            id: "key"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                data.log("Fetch DB item: " + data.action.id);
                if (botManager.data.bots[data.botId].database.hasOwnProperty(data.action.id)) {
                    resolve(botManager.data.bots[data.botId].database[data.action.id]);
                } else {
                    data.log("DB item " + data.action.id + " did not exist at fetch DB item");
                    resolve("null");
                }
            });
        }
    },

    "set-database-item": {
        allowedEvents: ["*"],
        name: "Set Datase Item",
        needs: ["id", "content"],
        inputs: {
            id: "key",
            content: "content"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                data.log("Set DB key " + data.action.id + " to " + data.action.content);

                if (!data.action.id.match(/^([a-zA-Z_0-9\-]{1,})$/)) {
                    data.log("Key was invalid: " + data.action.id);
                    reject("Key name: " + data.action.id + " is invalid");
                }

                botManager.data.bots[data.botId].database[data.action.id] =
                    parse(data.action.content, data.variables, data.client, data.botId);
                botManager.save();
                resolve();
            });
        }
    },

    "delete-database-item": {
        allowedEvents: ["*"],
        name: "Delete Database Item",
        needs: ["id"],
        inputs: {
            id: "key"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                data.log("Deleting key " + data.action.id);
                if (botManager.data.bots[data.botId].database.hasOwnProperty(data.action.id)) {
                    delete botManager.data.bots[data.botId].database[data.action.id];
                    botManager.save();
                    resolve();
                } else {
                    data.log("Key " + data.action.id + " did not exist at delete key");
                    resolve(null);
                }
            });
        }
    },

    "db-item-not-exist": {
        allowedEvents: ["*"],
        name: "If Database Item Does Not Exist, Set It To",
        needs: ["id", "content"],
        inputs: {
            id: "key",
            content: "content"
        },
        execute: (data) => {
            return new Promise((resolve, reject) => {
                if (!botManager.data.bots[data.botId].database.hasOwnProperty(data.action.id)) {
                    if (!data.action.id.match(/^([a-zA-Z_0-9\-]{1,})$/)) {
                        data.log("Key was invalid: " + data.action.id);
                        reject("Key name: " + data.action.id + " is invalid");
                    }

                    botManager.data.bots[data.botId].database[data.action.id] = data.action.content;
                    resolve();
                }

                resolve();
            });
        }
    },
}